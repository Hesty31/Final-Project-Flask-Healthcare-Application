import csv

class User:
    def __init__(self, age, gender, income, expenses):
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses

    def to_csv(self, filename='user_data.csv', header=False):
        
        with open(filename, mode='a', newline='') as file:
            writer = csv.writer(file)
            if header:
                writer.writerow(['Age', 'Gender', 'Income', 'Expenses'])
            else:
                writer.writerow([self.age, self.gender, self.income, self.expenses])
